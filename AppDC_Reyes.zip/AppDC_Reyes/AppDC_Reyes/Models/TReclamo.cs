﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace AppDC_Reyes.Models;

public partial class TReclamo
{
    public int IdReclamo { get; set; }

    [Required(ErrorMessage = "El nombre del proveedor es obligatorio.")]
    public string NombreProveedor { get; set; } = null!;

    [Required(ErrorMessage = "La direccion del proveedor es obligatoria.")]
    public string DireccionProveedor { get; set; } = null!;
    
    [Required(ErrorMessage = "El nombre del consumidor es obligatorio.")]
    public string NombresConsumidor { get; set; } = null!;
    
    [Required(ErrorMessage = "El apellido del consumidor es obligatorio. ")]
    public string ApellidosConsumidor { get; set; } = null!;

    [Required(ErrorMessage = "El DUI es obligatorio.")]
    [StringLength(10, ErrorMessage = "El DUI debe tener 10 caracteres.")]
    public string Dui { get; set; } = null!;

    [Required(ErrorMessage = "El detalle del reclamo es obligatorio.")]
    public string DetalleReclamo { get; set; } = null!;

    [Range(0.01, double.MaxValue, ErrorMessage = "El mondo debe ser mayor o igual a 0.01.")]
    public decimal? MontoReclamado { get; set; }

    [Phone(ErrorMessage = "El telefono debe tener un formato valido.")]
    public string? Telefono { get; set; }

    [Required(ErrorMessage = "La fecha de ingreso es obligatoria.")]
    public DateTime FechaIngreso { get; set; }
}
