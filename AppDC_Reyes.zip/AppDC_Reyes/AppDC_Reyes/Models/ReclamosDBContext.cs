﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace AppDC_Reyes.Models;

public partial class ReclamosDBContext : DbContext
{
    public ReclamosDBContext()
    {
    }

    public ReclamosDBContext(DbContextOptions<ReclamosDBContext> options)
        : base(options)
    {
    }

    public virtual DbSet<TReclamo> TReclamos { get; set; }

  //  protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
//#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
  //      => optionsBuilder.UseSqlServer("Server=HOSTWINDOWSLAB;Database=DBecario_Reyes;Trusted_Connection=True; TrustServerCertificate=True;");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<TReclamo>(entity =>
        {
            entity.HasKey(e => e.IdReclamo).HasName("PK__t_reclam__5EB0D864679A7CA7");

            entity.ToTable("t_reclamos");

            entity.Property(e => e.IdReclamo).HasColumnName("idReclamo");
            entity.Property(e => e.ApellidosConsumidor)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("apellidosConsumidor");
            entity.Property(e => e.DetalleReclamo)
                .HasMaxLength(250)
                .IsUnicode(false)
                .HasColumnName("detalleReclamo");
            entity.Property(e => e.DireccionProveedor)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("direccionProveedor");
            entity.Property(e => e.Dui)
                .HasMaxLength(10)
                .IsUnicode(false)
                .HasColumnName("DUI");
            entity.Property(e => e.FechaIngreso)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime")
                .HasColumnName("fechaIngreso");
            entity.Property(e => e.MontoReclamado)
                .HasColumnType("decimal(18, 2)")
                .HasColumnName("montoReclamado");
            entity.Property(e => e.NombreProveedor)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("nombreProveedor");
            entity.Property(e => e.NombresConsumidor)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("nombresConsumidor");
            entity.Property(e => e.Telefono)
                .HasMaxLength(10)
                .IsUnicode(false)
                .HasColumnName("telefono");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
