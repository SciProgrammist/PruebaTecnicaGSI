﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using AppDC_Reyes.Models;

namespace AppDC_Reyes.Controllers
{
    public class ReclamosController : Controller
    {
        private readonly ReclamosDBContext _context;

        public ReclamosController(ReclamosDBContext context)
        {
            _context = context;
        }

        // GET: Reclamos
        public async Task<IActionResult> Index()
        {
            return View(await _context.TReclamos.ToListAsync());
        }

        // GET: Reclamos/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var tReclamo = await _context.TReclamos
                .FirstOrDefaultAsync(m => m.IdReclamo == id);
            if (tReclamo == null)
            {
                return NotFound();
            }

            return View(tReclamo);
        }

        // GET: Reclamos/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Reclamos/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("IdReclamo,NombreProveedor,DireccionProveedor,NombresConsumidor,ApellidosConsumidor,Dui,DetalleReclamo,MontoReclamado,Telefono,FechaIngreso")] TReclamo tReclamo)
        {
            /***
             * La funcionalidad debe agregar directamente a la base de datos. (40%)  CHECK ON Controller Create function.
                • Validar campos vacíos. (10%)  CHECKED ON ModelState.IsValid
                • No permitir registros con DUI repetidos. (10%)  CHECKED on if clause in Controller for POST Data.
                • No permitir que se registren montos con valores negativos o menores a 0.01 (10%) CHECKED ON DataNotations for Model TReclamo
             */

            bool duiExists = await _context.TReclamos.AnyAsync(r => r.Dui == tReclamo.Dui);
            if (duiExists)
            {
                ModelState.AddModelError("Dui", "El DUI ya esta registrado.");
            
            }
            if (ModelState.IsValid)
            {
                _context.Add(tReclamo);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(tReclamo);
        }

        // GET: Reclamos/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var tReclamo = await _context.TReclamos.FindAsync(id);
            if (tReclamo == null)
            {
                return NotFound();
            }
            return View(tReclamo);
        }

        // POST: Reclamos/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("IdReclamo,NombreProveedor,DireccionProveedor,NombresConsumidor,ApellidosConsumidor,Dui,DetalleReclamo,MontoReclamado,Telefono,FechaIngreso")] TReclamo tReclamo)
        {
            if (id != tReclamo.IdReclamo)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(tReclamo);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!TReclamoExists(tReclamo.IdReclamo))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(tReclamo);
        }

        // GET: Reclamos/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var tReclamo = await _context.TReclamos
                .FirstOrDefaultAsync(m => m.IdReclamo == id);
            if (tReclamo == null)
            {
                return NotFound();
            }

            return View(tReclamo);
        }

        // POST: Reclamos/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var tReclamo = await _context.TReclamos.FindAsync(id);
            if (tReclamo != null)
            {
                _context.TReclamos.Remove(tReclamo);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool TReclamoExists(int id)
        {
            return _context.TReclamos.Any(e => e.IdReclamo == id);
        }
    }
}
